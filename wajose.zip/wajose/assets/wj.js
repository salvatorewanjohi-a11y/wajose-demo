/*
 * Wajose Main Shop: shop filters (category, size, sort), the quick-buy dialog (size, colour, quantity, live subtotal
 * with automatic wholesale pricing), the cart (localStorage) with two checkout modes that both end in an itemised
 * WhatsApp order, the wholesale inquiry form and the reviews carousel. Data comes from window.WJ, printed by
 * functions.php from the WooCommerce products, so the static Vercel copy behaves exactly like WordPress.
 */
( function () {
	const WJ = window.WJ || { products: {}, delivery: {}, payments: {}, cats: {}, moq: 6, freeOver: 0 };
	const $ = ( s, r = document ) => r.querySelector( s );
	const $$ = ( s, r = document ) => [ ...r.querySelectorAll( s ) ];
	const ksh = ( n ) => 'KSh ' + Math.round( Number( n ) ).toLocaleString( 'en-KE' );
	const wa = ( text ) => `https://wa.me/${ WJ.wa }?text=${ encodeURIComponent( text ) }`;
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	const phoneOk = ( v ) => /^(?:\+?254|0)?[17]\d{8}$/.test( String( v ).replace( /[\s-]/g, '' ) );
	const CHECK = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="m5 12 5 5 9-10"/></svg>';
	const P = WJ.products;
	const MOQ = WJ.moq;
	const unitFor = ( id, totalQty ) => ( P[ id ].whole && totalQty >= MOQ ? P[ id ].whole : P[ id ].price );

	/* Toasts ------------------------------------------------------------------------------------------------------ */
	const toasts = $( '[data-wj-toasts]' );
	function toast( title, body ) {
		if ( ! toasts ) return;
		const el = document.createElement( 'div' );
		el.className = 'wj-toast';
		el.innerHTML = `<span class="wj-toast__icon">${ CHECK }</span><p><b>${ esc( title ) }</b>${ body ? `<span>${ esc( body ) }</span>` : '' }</p>`;
		toasts.append( el );
		while ( toasts.children.length > 3 ) toasts.firstChild.remove();
		setTimeout( () => el.classList.add( 'is-out' ), 3200 );
		setTimeout( () => el.remove(), 3600 );
	}

	// The header gains a shadow once the page scrolls.
	const paint = () => document.body.classList.toggle( 'wj-scrolled', window.scrollY > 40 );
	paint();
	addEventListener( 'scroll', paint, { passive: true } );

	// Scroll to an element below the sticky header.
	const goTo = ( el ) => {
		if ( ! el ) return;
		const head = $( '.wj-header' )?.offsetHeight || 0;
		const bar = document.body.classList.contains( 'admin-bar' ) ? 32 : 0;
		window.scrollTo( { top: el.getBoundingClientRect().top + window.scrollY - head - bar - 10, behavior: 'smooth' } );
	};

	/* Shop filters ------------------------------------------------------------------------------------------------ */
	const shop = $( '[data-wj-shop]' );
	const grid = shop && $( '.wj-cards', shop );
	const sizeSel = shop && $( '[data-wj-size]', shop );
	const sortSel = shop && $( '[data-wj-sort]', shop );
	const f = { cat: 'all', size: '', sort: 'featured' };

	function applyFilters( scroll ) {
		if ( ! shop ) return;
		if ( f.cat !== 'all' && ! $( `[data-wj-cat="${ f.cat }"]`, shop ) ) f.cat = 'all';
		$$( '[data-wj-cat]', shop ).forEach( ( b ) => {
			const on = b.dataset.wjCat === f.cat;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on );
		} );
		$$( '[data-wj-cat-note]', shop ).forEach( ( p ) => ( p.hidden = p.dataset.wjCatNote !== f.cat ) );
		const cards = $$( '.wj-card', grid );
		const key = { featured: ( c ) => +c.dataset.order, new: ( c ) => ( c.dataset.new === '1' ? 0 : 1 ) * 1000 + +c.dataset.order, low: ( c ) => +c.dataset.price, high: ( c ) => -c.dataset.price }[ f.sort ];
		cards.sort( ( a, b ) => key( a ) - key( b ) ).forEach( ( c ) => grid.append( c ) );
		let shown = 0;
		cards.forEach( ( c ) => {
			const inCat = f.cat === 'all' || ( f.cat === 'new' ? c.dataset.new === '1' : c.dataset.cat === f.cat );
			const inSize = ! f.size || c.dataset.sizes.split( ' ' ).includes( f.size );
			c.hidden = ! ( inCat && inSize );
			if ( ! c.hidden ) shown++;
			// Highlight the chosen size on each card.
			$$( '.wj-card__sizes button', c ).forEach( ( b ) => b.classList.toggle( 'is-on', b.dataset.size === f.size ) );
		} );
		$( '[data-wj-results]', shop ).textContent = `${ shown } style${ shown === 1 ? '' : 's' }${ f.size ? ` in size ${ f.size }` : '' }`;
		$( '[data-wj-none]', shop ).hidden = !! shown;
		// "Shop all" with no size filter is capped on small screens (CSS) until the visitor asks for the rest.
		const capped = f.cat === 'all' && ! f.size && ! shop.dataset.expanded;
		grid.classList.toggle( 'is-capped', capped );
		$( '[data-wj-more]', shop ).hidden = ! capped;
		if ( scroll ) goTo( $( '#shop' ) );
	}
	if ( shop ) {
		shop.addEventListener( 'click', ( e ) => {
			if ( e.target.closest( '[data-wj-more]' ) ) {
				shop.dataset.expanded = '1';
				return applyFilters( false );
			}
			if ( e.target.closest( '[data-wj-reset]' ) ) {
				Object.assign( f, { cat: 'all', size: '' } );
				sizeSel.value = '';
				return applyFilters( false );
			}
			const b = e.target.closest( '[data-wj-cat]' );
			if ( b ) {
				f.cat = b.dataset.wjCat;
				history.replaceState( null, '', ( f.cat === 'all' ? location.pathname : `?cat=${ f.cat }` ) + '#shop' );
				applyFilters( false );
			}
		} );
		sizeSel.addEventListener( 'change', () => {
			f.size = sizeSel.value;
			applyFilters( false );
		} );
		sortSel.addEventListener( 'change', () => {
			f.sort = sortSel.value;
			applyFilters( false );
		} );
	}
	// Menu and category links like /?cat=executive#shop filter in place instead of reloading.
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( 'a[href*="cat="]' );
		if ( ! a || ! shop ) return;
		const url = new URL( a.href, location.href );
		if ( url.pathname !== location.pathname ) return;
		e.preventDefault();
		history.replaceState( null, '', url.search + '#shop' );
		f.cat = url.searchParams.get( 'cat' ) || 'all';
		applyFilters( true );
		$( '.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-close' )?.click();
	} );
	const params = new URLSearchParams( location.search );
	if ( params.get( 'cat' ) ) f.cat = params.get( 'cat' );
	applyFilters( false );

	/* Cart state --------------------------------------------------------------------------------------------------- */
	const KEY = 'wj-cart-v1';
	let cart = {}; // "id|size|colour" → qty
	try {
		cart = JSON.parse( localStorage.getItem( KEY ) || '{}' ) || {};
	} catch {}
	for ( const k of Object.keys( cart ) ) if ( ! P[ k.split( '|' )[ 0 ] ] || ! ( cart[ k ] > 0 ) ) delete cart[ k ];
	const save = () => {
		try {
			localStorage.setItem( KEY, JSON.stringify( cart ) );
		} catch {}
	};
	const qtyOf = ( id ) => Object.keys( cart ).reduce( ( n, k ) => n + ( k.split( '|' )[ 0 ] === id ? cart[ k ] : 0 ), 0 );
	const label = ( size, colour, id ) => [ size && `${ P[ id ].sizeLabel === 'Size' ? 'Size ' : '' }${ size }`, colour ].filter( Boolean ).join( ' · ' );

	/* Quick-buy dialog --------------------------------------------------------------------------------------------- */
	const modal = $( '[data-wj-modal]' );
	const q = { id: '', size: '', colour: '', qty: 1 };
	const qtyIn = modal && $( '[data-wj-q-qty]', modal );
	let lastFocus = null;

	function openQuick( id, size ) {
		const p = P[ id ];
		if ( ! p || ! modal ) return;
		lastFocus = document.activeElement;
		Object.assign( q, { id, size: p.sizes.includes( size ) ? size : p.sizes.includes( f.size ) ? f.size : '', colour: p.colours.length === 1 ? p.colours[ 0 ] : '', qty: 1 } );
		qtyIn.value = 1;
		$( '[data-wj-q-img]', modal ).src = p.img;
		$( '[data-wj-q-img]', modal ).alt = p.name;
		const badge = $( '[data-wj-q-badge]', modal );
		badge.hidden = ! p.badge;
		badge.textContent = p.badge;
		$( '[data-wj-q-cat]', modal ).textContent = WJ.cats[ p.cat ] || '';
		$( '[data-wj-q-name]', modal ).textContent = p.name;
		$( '[data-wj-q-desc]', modal ).textContent = p.desc;
		$( '[data-wj-q-price]', modal ).textContent = ksh( p.price );
		$( '[data-wj-q-wholewrap]', modal ).hidden = ! p.whole;
		$( '[data-wj-q-whole]', modal ).textContent = p.whole ? `${ ksh( p.whole ) } / pc` : '';
		$( '[data-wj-q-sizelabel]', modal ).textContent = p.sizeLabel;
		$( '[data-wj-q-sizes]', modal ).innerHTML = p.sizes.map( ( s ) => `<button type="button" data-wj-q-size="${ esc( s ) }">${ esc( s ) }</button>` ).join( '' );
		$( '[data-wj-q-colours]', modal ).innerHTML = p.colours.map( ( c ) => `<button type="button" data-wj-q-col="${ esc( c ) }">${ esc( c ) }</button>` ).join( '' );
		$( '[data-wj-q-error]', modal ).hidden = true;
		modal.hidden = false;
		document.documentElement.style.overflow = 'hidden';
		renderQuick();
		$( '.wj-x', modal ).focus();
	}
	function closeQuick() {
		if ( ! modal || modal.hidden ) return;
		modal.hidden = true;
		document.documentElement.style.overflow = drawer && ! drawer.hidden ? 'hidden' : '';
		lastFocus?.focus?.();
	}
	function renderQuick() {
		const p = P[ q.id ];
		q.qty = Math.max( 1, Math.min( 500, parseInt( qtyIn.value, 10 ) || 1 ) );
		if ( String( q.qty ) !== qtyIn.value && document.activeElement !== qtyIn ) qtyIn.value = q.qty;
		$$( '[data-wj-q-size]', modal ).forEach( ( b ) => {
			b.classList.toggle( 'is-on', b.dataset.wjQSize === q.size );
			b.setAttribute( 'aria-pressed', b.dataset.wjQSize === q.size );
		} );
		$$( '[data-wj-q-col]', modal ).forEach( ( b ) => {
			b.classList.toggle( 'is-on', b.dataset.wjQCol === q.colour );
			b.setAttribute( 'aria-pressed', b.dataset.wjQCol === q.colour );
		} );
		$( '[data-wj-q-sizehint]', modal ).textContent = q.size ? `· ${ q.size }` : '· choose one';
		$( '[data-wj-q-colour]', modal ).textContent = q.colour ? `· ${ q.colour }` : '· choose one';
		// Wholesale counts every piece of this style: what's already in the cart plus this selection.
		const already = qtyOf( q.id );
		const unit = unitFor( q.id, already + q.qty );
		$( '[data-wj-q-sub]', modal ).textContent = ksh( unit * q.qty );
		let tier = '';
		if ( p.whole ) {
			const need = MOQ - already - q.qty;
			tier = need > 0 ? `Add ${ need } more for wholesale: ${ ksh( p.whole ) } each` : `Wholesale price applied · you save ${ ksh( ( p.price - p.whole ) * q.qty ) }`;
			if ( already ) tier += ` (${ already } already in cart)`;
		} else if ( p.cat === 'wholesale' ) {
			tier = 'Bulk pack price';
		}
		const tierEl = $( '[data-wj-q-tier]', modal );
		tierEl.textContent = tier;
		tierEl.classList.toggle( 'is-gold', p.whole && unit === p.whole );
		const msg = [
			`Hi Wajose! I'd like to buy:`,
			`• ${ p.name }${ label( q.size, q.colour, q.id ) ? ` (${ label( q.size, q.colour, q.id ) })` : '' } × ${ q.qty } = ${ ksh( unit * q.qty ) }`,
			'',
			'Is it available? Please share delivery and payment details.',
		].join( '\n' );
		$( '[data-wj-q-wa]', modal ).href = wa( msg );
	}
	const quickError = () => {
		const p = P[ q.id ];
		if ( p.sizes.length && ! q.size ) return `Please choose a ${ p.sizeLabel.toLowerCase() }.`;
		if ( p.colours.length && ! q.colour ) return 'Please choose a colour.';
		return '';
	};
	if ( modal ) {
		modal.addEventListener( 'click', ( e ) => {
			const t = e.target;
			if ( t.closest( '[data-wj-close-modal]' ) ) return closeQuick();
			const s = t.closest( '[data-wj-q-size]' );
			if ( s ) q.size = s.dataset.wjQSize;
			const c = t.closest( '[data-wj-q-col]' );
			if ( c ) q.colour = c.dataset.wjQCol;
			const st = t.closest( '[data-wj-q-step]' );
			if ( st ) qtyIn.value = Math.max( 1, ( parseInt( qtyIn.value, 10 ) || 1 ) + Number( st.dataset.wjQStep ) );
			if ( s || c || st ) {
				$( '[data-wj-q-error]', modal ).hidden = true;
				return renderQuick();
			}
			const errEl = $( '[data-wj-q-error]', modal );
			if ( t.closest( '[data-wj-q-add]' ) || t.closest( '[data-wj-q-wa]' ) ) {
				const err = quickError();
				if ( err ) {
					e.preventDefault();
					errEl.textContent = err;
					errEl.hidden = false;
					return;
				}
			}
			if ( t.closest( '[data-wj-q-add]' ) ) {
				const k = [ q.id, q.size, q.colour ].join( '|' );
				const before = qtyOf( q.id );
				cart[ k ] = ( cart[ k ] || 0 ) + q.qty;
				save();
				renderCart();
				closeQuick();
				const p = P[ q.id ];
				toast( 'Added to your cart', `${ p.name }${ label( q.size, q.colour, q.id ) ? ' · ' + label( q.size, q.colour, q.id ) : '' } × ${ q.qty }` );
				if ( p.whole && before < MOQ && before + q.qty >= MOQ ) setTimeout( () => toast( 'Wholesale price unlocked', `${ p.name } now ${ ksh( p.whole ) } each` ), 400 );
				bump();
			}
		} );
		qtyIn.addEventListener( 'input', renderQuick );
		qtyIn.addEventListener( 'blur', () => ( qtyIn.value = q.qty ) );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-wj-quick]' );
		if ( b ) openQuick( b.dataset.wjQuick, b.dataset.size || '' );
	} );

	/* Cart drawer -------------------------------------------------------------------------------------------------- */
	const drawer = $( '[data-wj-drawer]' );
	const countEl = $( '[data-wj-count]' );
	const floatWa = $( '.wj-float-wa' );
	let mode = 'wa';
	const ref = 'WJ-' + Math.random().toString( 36 ).slice( 2, 6 ).toUpperCase();
	const field = ( n ) => $( `[data-wj-f="${ n }"]`, drawer );

	function bump() {
		if ( ! countEl ) return;
		countEl.classList.remove( 'is-pop' );
		void countEl.offsetWidth;
		countEl.classList.add( 'is-pop' );
	}

	function totals() {
		const keys = Object.keys( cart );
		const lines = keys.map( ( k ) => {
			const [ id, size, colour ] = k.split( '|' );
			const unit = unitFor( id, qtyOf( id ) );
			return { k, id, size, colour, qty: cart[ k ], unit, total: unit * cart[ k ], retail: P[ id ].price * cart[ k ] };
		} );
		const subtotal = lines.reduce( ( n, l ) => n + l.total, 0 );
		const save = lines.reduce( ( n, l ) => n + l.retail - l.total, 0 );
		const dk = $( 'input[name="wj-deliv"]:checked', drawer )?.value || 'rider';
		const d = WJ.delivery[ dk ];
		const free = dk === 'rider' && WJ.freeOver && subtotal >= WJ.freeOver;
		const fee = free ? 0 : d.fee;
		return { lines, subtotal, save, dk, d, fee, free, count: lines.reduce( ( n, l ) => n + l.qty, 0 ) };
	}

	function formError( t ) {
		if ( mode !== 'form' ) return '';
		if ( field( 'name' ).value.trim().length < 2 ) return 'Please enter your name.';
		if ( ! phoneOk( field( 'phone' ).value ) ) return 'Please enter a Kenyan phone number like 0712 345 678.';
		if ( t.dk !== 'pickup' && field( 'address' ).value.trim().length < 3 ) return t.dk === 'courier' ? 'Please enter your town and courier office.' : 'Please enter your delivery address.';
		if ( $( 'input[name="wj-pay"]:checked', drawer )?.value === 'cod' && t.dk !== 'rider' ) return 'Cash on delivery is for Nairobi rider orders. Choose M-Pesa or bank transfer.';
		return '';
	}

	function renderCart() {
		const t = totals();
		if ( countEl ) {
			countEl.hidden = ! t.count;
			countEl.textContent = t.count;
		}
		$( '[data-wj-open-cart]' )?.setAttribute( 'aria-label', `Open cart, ${ t.count } item${ t.count === 1 ? '' : 's' }` );
		if ( ! drawer ) return;
		$( '[data-wj-empty]', drawer ).hidden = !! t.lines.length;
		$( '[data-wj-full]', drawer ).hidden = ! t.lines.length;
		$( '[data-wj-cart-count]', drawer ).textContent = t.count ? `(${ t.count })` : '';
		if ( ! t.lines.length ) return;
		$( '[data-wj-lines]', drawer ).innerHTML = t.lines
			.map( ( l ) => {
				const p = P[ l.id ];
				const isWhole = p.whole && l.unit === p.whole;
				return `<li class="wj-line"><div class="wj-line__img"><img src="${ esc( p.img ) }" alt=""></div><div class="wj-line__body"><b>${ esc( p.name ) }</b><small>${ esc( label( l.size, l.colour, l.id ) ) }</small>
					<small class="${ isWhole ? 'is-gold' : '' }">${ ksh( l.unit ) } each${ isWhole ? ' · wholesale' : '' }</small>
					<div class="wj-line__row"><div class="wj-qty wj-qty--sm"><button type="button" data-wj-step="${ esc( l.k ) }" data-d="-1" aria-label="Decrease quantity">−</button><span>${ l.qty }</span><button type="button" data-wj-step="${ esc( l.k ) }" data-d="1" aria-label="Increase quantity">+</button></div><span>${ ksh( l.total ) }</span></div></div>
					<button type="button" class="wj-line__rm" data-wj-rm="${ esc( l.k ) }" aria-label="Remove ${ esc( p.name ) }">×</button></li>`;
			} )
			.join( '' );
		// Nudge towards wholesale for styles that are close to the minimum.
		const near = [ ...new Set( t.lines.map( ( l ) => l.id ) ) ].filter( ( id ) => P[ id ].whole && qtyOf( id ) < MOQ && qtyOf( id ) >= Math.max( 2, MOQ - 3 ) );
		const hint = $( '[data-wj-tierhint]', drawer );
		hint.hidden = ! near.length;
		hint.textContent = near.length ? `Add ${ MOQ - qtyOf( near[ 0 ] ) } more ${ P[ near[ 0 ] ].name } (any size or colour) to unlock ${ ksh( P[ near[ 0 ] ].whole ) } each.` : '';
		// Delivery labels: free rider delivery over the threshold.
		$$( '[data-wj-fee]', drawer ).forEach( ( el ) => {
			const k = el.dataset.wjFee;
			el.textContent = k === 'rider' && WJ.freeOver && t.subtotal >= WJ.freeOver ? 'Free' : WJ.delivery[ k ].fee ? ksh( WJ.delivery[ k ].fee ) : 'Free';
		} );
		const addr = $( '[data-wj-addr]', drawer );
		addr.hidden = t.dk === 'pickup';
		$( '[data-wj-addr-label]', drawer ).textContent = t.dk === 'courier' ? 'Town and courier office' : 'Delivery address in Nairobi';
		field( 'address' ).placeholder = t.dk === 'courier' ? 'e.g. Kisumu, G4S Oginga Odinga St' : 'Estate, street, building, house no.';
		$( '[data-wj-subtotal]', drawer ).textContent = ksh( t.subtotal + t.save );
		$( '[data-wj-savewrap]', drawer ).hidden = ! t.save;
		$( '[data-wj-save]', drawer ).textContent = '−' + ksh( t.save );
		$( '[data-wj-deliv-label]', drawer ).textContent = t.d.label;
		$( '[data-wj-deliv-fee]', drawer ).textContent = t.fee ? ksh( t.fee ) : 'Free';
		$( '[data-wj-grand]', drawer ).textContent = ksh( t.subtotal + t.fee );
		$( '[data-wj-checkout-label]', drawer ).textContent = mode === 'form' ? `Place order ${ ref } on WhatsApp` : 'Send order on WhatsApp';

		const items = t.lines.map( ( l, i ) => `${ i + 1 }. ${ P[ l.id ].name }${ label( l.size, l.colour, l.id ) ? ` (${ label( l.size, l.colour, l.id ) })` : '' } × ${ l.qty } @ ${ ksh( l.unit ) } = ${ ksh( l.total ) }${ P[ l.id ].whole && l.unit === P[ l.id ].whole ? ' [wholesale]' : '' }` );
		const money = [
			`Subtotal: ${ ksh( t.subtotal ) }${ t.save ? ` (wholesale savings ${ ksh( t.save ) })` : '' }`,
			`${ t.d.label }: ${ t.fee ? ksh( t.fee ) : 'Free' }`,
			`*Total: ${ ksh( t.subtotal + t.fee ) }*`,
		];
		let msg;
		if ( mode === 'form' ) {
			const pay = WJ.payments[ $( 'input[name="wj-pay"]:checked', drawer )?.value || 'mpesa' ][ 0 ];
			const notes = field( 'notes' ).value.trim();
			msg = [
				`Hi Wajose! New order *${ ref }*`,
				'',
				...items,
				'',
				...money,
				'',
				`Name: ${ field( 'name' ).value.trim() }`,
				`Phone: ${ field( 'phone' ).value.trim() }`,
				t.dk === 'pickup' ? 'Delivery: I will collect from the Nairobi hub' : `${ t.dk === 'courier' ? 'Courier to' : 'Deliver to' }: ${ field( 'address' ).value.trim() }`,
				...( notes ? [ `Instructions: ${ notes }` ] : [] ),
				`Payment: ${ pay }`,
				'',
				'Please confirm stock and send payment details. Thank you!',
			].join( '\n' );
		} else {
			msg = [ "Hi Wajose! I'd like to order:", '', ...items, '', ...money, '', 'Please confirm availability, delivery and payment. Thank you!' ].join( '\n' );
		}
		$( '[data-wj-checkout]', drawer ).href = wa( msg );
	}

	function openCart( open ) {
		if ( ! drawer ) return;
		drawer.hidden = ! open;
		floatWa?.classList.toggle( 'is-away', open );
		document.documentElement.style.overflow = open ? 'hidden' : '';
		if ( open ) {
			renderCart();
			$( '.wj-x', drawer )?.focus();
		}
	}

	document.addEventListener( 'click', ( e ) => {
		const t = e.target;
		if ( t.closest( '[data-wj-open-cart]' ) ) return openCart( true );
		if ( t.closest( '[data-wj-close]' ) ) return openCart( false );
		const st = t.closest( '[data-wj-step]' );
		if ( st ) {
			const k = st.dataset.wjStep;
			cart[ k ] = ( cart[ k ] || 0 ) + Number( st.dataset.d );
			if ( cart[ k ] <= 0 ) delete cart[ k ];
			save();
			return renderCart();
		}
		const rm = t.closest( '[data-wj-rm]' );
		if ( rm ) {
			delete cart[ rm.dataset.wjRm ];
			save();
			return renderCart();
		}
		if ( t.closest( '[data-wj-clear]' ) ) {
			cart = {};
			save();
			return renderCart();
		}
		const m = t.closest( '[data-wj-mode]' );
		if ( m ) {
			mode = m.dataset.wjMode;
			$$( '[data-wj-mode]', drawer ).forEach( ( b ) => {
				b.classList.toggle( 'is-on', b === m );
				b.setAttribute( 'aria-selected', b === m );
			} );
			$$( '[data-wj-mode-note]', drawer ).forEach( ( n ) => ( n.hidden = n.dataset.wjModeNote !== mode ) );
			$( '[data-wj-co-error]', drawer ).hidden = true;
			return renderCart();
		}
		if ( t.closest( '[data-wj-checkout]' ) ) {
			renderCart();
			const err = formError( totals() );
			const errEl = $( '[data-wj-co-error]', drawer );
			errEl.hidden = ! err;
			errEl.textContent = err;
			if ( err ) {
				e.preventDefault();
				return;
			}
			toast( 'Opening WhatsApp', mode === 'form' ? `Order ${ ref } is ready to send` : 'Your itemised order is ready to send' );
		}
	} );
	drawer?.addEventListener( 'change', renderCart );
	drawer?.addEventListener( 'input', () => {
		$( '[data-wj-co-error]', drawer ).hidden = true;
		renderCart();
	} );
	document.addEventListener( 'keydown', ( e ) => {
		if ( e.key !== 'Escape' ) return;
		if ( modal && ! modal.hidden ) return closeQuick();
		if ( drawer && ! drawer.hidden ) openCart( false );
	} );
	renderCart();

	// A shared product link (/?p=slug#shop) opens its quick-buy dialog.
	if ( params.get( 'p' ) && P[ params.get( 'p' ) ] ) setTimeout( () => openQuick( params.get( 'p' ), '' ), 300 );

	/* Wholesale inquiry -------------------------------------------------------------------------------------------- */
	const wform = $( '[data-wj-wholesale]' );
	wform?.addEventListener( 'submit', ( e ) => {
		e.preventDefault();
		const d = new FormData( wform );
		const v = ( k ) => String( d.get( k ) || '' ).trim();
		const err = ! v( 'biz' ) ? 'Please add your business name.' : v( 'name' ).length < 2 ? 'Please add your name.' : ! phoneOk( v( 'phone' ) ) ? 'Please enter a Kenyan phone number like 0712 345 678.' : ! v( 'town' ) ? 'Please add your town.' : '';
		const errEl = $( '[data-wj-error]', wform );
		errEl.hidden = ! err;
		errEl.textContent = err;
		if ( err ) return;
		const interests = d.getAll( 'wj-int' );
		const msg = [
			'Hi Wajose! Wholesale inquiry:',
			'',
			`Business: ${ v( 'biz' ) }`,
			`Contact: ${ v( 'name' ) }, ${ v( 'phone' ) }`,
			`Town: ${ v( 'town' ) }`,
			`Interested in: ${ interests.length ? interests.join( ', ' ) : 'Your full range' }`,
			`Order size: ${ v( 'qty' ) }`,
			...( v( 'notes' ) ? [ `Notes: ${ v( 'notes' ) }` ] : [] ),
			'',
			'Please send your wholesale price list. Thank you!',
		].join( '\n' );
		window.open( wa( msg ), '_blank', 'noopener' );
		toast( 'Opening WhatsApp', 'Your wholesale inquiry is ready to send' );
	} );

	/* Reviews carousel --------------------------------------------------------------------------------------------- */
	const car = $( '[data-wj-carousel]' );
	if ( car ) {
		const track = $( '[data-wj-track]', car );
		const slides = $$( 'li', track );
		const dots = $( '[data-wj-dots]', car );
		dots.innerHTML = slides.map( ( _, i ) => `<button type="button" aria-label="Review ${ i + 1 }"></button>` ).join( '' );
		const step = () => slides[ 0 ].getBoundingClientRect().width + parseFloat( getComputedStyle( track ).columnGap || 0 );
		const current = () => Math.round( track.scrollLeft / step() );
		const go = ( i ) => track.scrollTo( { left: ( ( i + slides.length ) % slides.length ) * step(), behavior: 'smooth' } );
		const mark = () => $$( 'button', dots ).forEach( ( b, i ) => b.setAttribute( 'aria-current', i === current() ) );
		track.addEventListener( 'scroll', () => requestAnimationFrame( mark ), { passive: true } );
		$( '[data-wj-prev]', car ).addEventListener( 'click', () => go( current() - 1 ) );
		$( '[data-wj-next]', car ).addEventListener( 'click', () => {
			const atEnd = track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;
			go( atEnd ? 0 : current() + 1 );
		} );
		dots.addEventListener( 'click', ( e ) => {
			const b = e.target.closest( 'button' );
			if ( b ) go( $$( 'button', dots ).indexOf( b ) );
		} );
		mark();
		let paused = matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		car.addEventListener( 'pointerenter', () => ( paused = true ) );
		car.addEventListener( 'pointerleave', () => ( paused = matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) );
		car.addEventListener( 'focusin', () => ( paused = true ) );
		setInterval( () => {
			if ( paused || document.hidden ) return;
			const atEnd = track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;
			go( atEnd ? 0 : current() + 1 );
		}, 6000 );
	}
} )();
