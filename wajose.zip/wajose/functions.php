<?php
/**
 * Wajose Main Shop child theme. Built like our Beauty Galore and RealBeef themes: the catalogue is WooCommerce
 * products (name, price, photo, Size and Colour attributes, plus a wholesale price field) rendered on a one-page shop.
 * The cart, quick-buy, wholesale pricing and both checkout modes run in the browser (assets/wj.js) and end in an
 * itemised WhatsApp order to the shop, so the static Vercel copy works exactly like WordPress.
 * What is real and what is a sample is listed in the project README.
 */

const WJ_NAME       = 'Wajose Main Shop';
const WJ_PHONE      = '0787 396 079';
const WJ_PHONE_INTL = '+254 787 396 079';
const WJ_TEL        = '+254787396079';
const WJ_WA         = '254787396079';
const WJ_HANDLE     = '@wajoseshop';
const WJ_IG         = 'https://www.instagram.com/wajoseshop/';  // From the brief; not yet confirmed (see README).
const WJ_TT         = 'https://www.tiktok.com/@wajoseshop';     // From the brief; not yet confirmed (see README).
const WJ_CITY       = 'Nairobi';
const WJ_MAP_Q      = 'Nairobi CBD, Nairobi, Kenya';             // Sample pin until Wajose shares its exact hub.
const WJ_PREVIEW    = true;  // Shows "sample" notes and keeps the site out of search until Wajose confirms.
const WJ_MOQ        = 6;     // Wholesale price from this many pieces of one style (sizes and colours can be mixed).
const WJ_FREE_OVER  = 20000; // Free Nairobi rider delivery from this order value (sample).
const WJ_FONTS      = 'https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,opsz,wght@0,6..96,400;0,6..96,500;0,6..96,600;1,6..96,400;1,6..96,500&family=Manrope:wght@400;500;600;700;800&display=swap';

/** Delivery options. Fees are samples until Wajose confirms. */
const WJ_DELIVERY = [
	'rider'   => [ 'label' => 'Nairobi rider delivery', 'detail' => 'Day or night, usually within 3 hours', 'fee' => 350 ],
	'courier' => [ 'label' => 'Countrywide courier', 'detail' => 'Any town in Kenya in 1–2 days', 'fee' => 500 ],
	'pickup'  => [ 'label' => 'Collect from our Nairobi hub', 'detail' => 'We send a live pin when it’s packed', 'fee' => 0 ],
];

/** Payment options for the checkout form. */
const WJ_PAYMENTS = [
	'mpesa' => [ 'M-Pesa', 'Till / Paybill details sent with your confirmation' ],
	'cod'   => [ 'Cash on delivery', 'Nairobi rider orders only' ],
	'bank'  => [ 'Bank transfer', 'Best for wholesale and bulk orders' ],
];

/** Placeholders until Wajose shares real customer reviews (with permission). */
const WJ_REVIEWS = [
	[ 'Ordered the horsebit loafers at 11pm and the rider was at my gate before 8am. Leather is soft and the fit is spot on.', 'Kevin M.', 'Westlands · Executive loafers' ],
	[ 'I restock my Eldoret boutique from Wajose every month. The 12-pair loafer pack sells out in two weeks every time.', 'Grace W.', 'Eldoret · Wholesale buyer' ],
	[ 'Wore the patent loafers to a wedding and three people asked where I got them. Six months later they still shine.', 'Brian O.', 'Kilimani · Patent loafers' ],
	[ 'They sent me photos of every size on WhatsApp before I paid. Easy exchange when my size was off by one.', 'Dennis K.', 'Thika · Sneakers' ],
	[ 'Good mix for my stall: drivers, slip-ons and sneakers in one bale, and they packed a full size run.', 'Mama Njeri', 'Gikomba · Casual shoe bundle' ],
];

/** Lookbook tiles in mosaic order (the 2nd and 7th are wide): [image, caption, wide]. Stock photos until Wajose sends its own. */
const WJ_LOOKBOOK = [
	[ 'look-store.jpg', 'Fitting day at the hub', false ],
	[ 'look-unbox.jpg', 'Unboxing: brogues in the box', true ],
	[ 'look-city.jpg', 'Weekend smart', false ],
	[ 'look-jacket.jpg', 'Overshirt season', false ],
	[ 'look-white.jpg', 'Crisp whites', false ],
	[ 'look-rack.jpg', 'New arrivals on the rail', false ],
	[ 'look-boots.jpg', 'Leather in three tones', true ],
	[ 'look-glasses.jpg', 'Office to evening', false ],
];

function wj_ksh( $n ) {
	return 'KSh ' . number_format( (float) $n );
}
function wj_wa( $text ) {
	return 'https://wa.me/' . WJ_WA . '?text=' . rawurlencode( $text );
}
function wj_asset( $name ) {
	return get_stylesheet_directory_uri() . '/assets/' . $name;
}

function wj_icon( $name, $size = 18 ) {
	$s     = 'fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"';
	$paths = [
		'wa'     => '<path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.4.1-.6.3-.2.2-.8.8-.8 2s.8 2.3 1 2.5c.1.2 1.6 2.5 4 3.5 1.5.6 2 .7 2.8.6.4-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2l-.5-.3z"/>',
		'bag'    => "<path $s d=\"M5 8h14l-1.2 12H6.2zM9 8V6a3 3 0 0 1 6 0v2\"/>",
		'check'  => "<path $s stroke-width=\"2\" d=\"m5 12 5 5 9-10\"/>",
		'crown'  => "<path $s d=\"M3 8l4.5 4L12 5l4.5 7L21 8l-2 10H5zM5 21h14\"/>",
		'truck'  => "<path $s d=\"M2 6h12v10H2zM14 9h4l4 4v3h-8M6 19.5a1.8 1.8 0 1 0 0-.1M18 19.5a1.8 1.8 0 1 0 0-.1\"/>",
		'clock'  => "<circle cx=\"12\" cy=\"12\" r=\"9\" $s/><path $s d=\"M12 7v5l3 2\"/>",
		'star'   => '<path fill="currentColor" d="m12 3 2.7 5.6 6.1.8-4.4 4.3 1 6.1L12 17l-5.4 2.8 1-6.1-4.4-4.3 6.1-.8z"/>',
		'tag'    => "<path $s d=\"M3 12V4h8l10 10-8 8zM7.5 7.5h.01\"/>",
		'gem'    => "<path $s d=\"M6 3h12l4 6-10 12L2 9zM2 9h20M12 21 8 9l4-6 4 6z\"/>",
		'box'    => "<path $s d=\"M3 7.5 12 3l9 4.5v9L12 21l-9-4.5zM3 7.5 12 12l9-4.5M12 12v9\"/>",
		'pin'    => "<path $s d=\"M12 21s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12z\"/><circle cx=\"12\" cy=\"9\" r=\"2.5\" $s/>",
		'phone'  => "<path $s d=\"M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z\"/>",
		'ig'     => "<rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"5\" $s/><circle cx=\"12\" cy=\"12\" r=\"4\" $s/><circle cx=\"17.3\" cy=\"6.7\" r=\"1.1\" fill=\"currentColor\"/>",
		'tiktok' => '<path fill="currentColor" d="M16.6 3c.4 2.2 1.8 3.6 4 3.8v3.1a7 7 0 0 1-4-1.3v6.3A5.9 5.9 0 1 1 10.7 9v3.2a2.8 2.8 0 1 0 2.8 2.8V3z"/>',
		'arrow'  => "<path $s d=\"M5 12h14M13 6l6 6-6 6\"/>",
		'ruler'  => "<path $s d=\"M3 17 17 3l4 4L7 21zM7 13l2 2M10 10l2 2M13 7l2 2\"/>",
		'swap'   => "<path $s d=\"M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7\"/>",
		'card'   => "<rect x=\"2\" y=\"5\" width=\"20\" height=\"14\" rx=\"2\" $s/><path $s d=\"M2 10h20M6 15h4\"/>",
		'cash'   => "<rect x=\"2\" y=\"6\" width=\"20\" height=\"12\" rx=\"2\" $s/><circle cx=\"12\" cy=\"12\" r=\"2.5\" $s/>",
		'mpesa'  => "<rect x=\"6\" y=\"2\" width=\"12\" height=\"20\" rx=\"2\" $s/><path $s d=\"M10 18h4\"/>",
		'filter' => "<path $s d=\"M4 6h16M7 12h10M10 18h4\"/>",
		'eye'    => "<path $s d=\"M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z\"/><circle cx=\"12\" cy=\"12\" r=\"3\" $s/>",
	];
	return '<svg viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" aria-hidden="true">' . ( $paths[ $name ] ?? '' ) . '</svg>';
}

/** Wajose's round W/S emblem on a white disc (cut from their own logo by dev/logo.cjs). */
function wj_mark( $size = 44 ) {
	return '<img class="wj-mark" src="' . esc_url( wj_asset( 'logo-mark.png' ) ) . '" width="' . $size . '" height="' . $size . '" alt="">';
}
function wj_logo( $extra = '' ) {
	return '<a href="/" class="wj-logo ' . esc_attr( $extra ) . '" aria-label="Wajose Main Shop home">' . wj_mark() . '<span><strong>Wajose</strong><em>Main Shop</em></span></a>';
}
/** The full Wajose Smart Wear logo (emblem, wordmark, script) on a white tile, for the footer. */
function wj_logo_full() {
	return '<a href="/" class="wj-logo-tile" aria-label="Wajose Main Shop home"><img src="' . esc_url( wj_asset( 'logo-full.jpg' ) ) . '" width="468" height="438" alt="Wajose Smart Wear logo" loading="lazy"></a>';
}

/** Shop categories in tab order. */
function wj_categories() {
	$out = [];
	foreach ( get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => false, 'exclude' => [ get_option( 'default_product_cat' ) ] ] ) as $t ) {
		// Term names are stored HTML-encoded ("&amp;"); decode once so both esc_html and the JSON for wj.js get plain text.
		$out[ $t->slug ] = [ 'name' => html_entity_decode( $t->name, ENT_QUOTES ), 'blurb' => html_entity_decode( $t->description, ENT_QUOTES ), 'order' => (int) get_term_meta( $t->term_id, 'order', true ) ];
	}
	uasort( $out, fn( $a, $b ) => $a['order'] <=> $b['order'] );
	return $out;
}

/** Reads a product attribute's options by name (Size / Size run / Colour). */
function wj_attr_options( $product, $names ) {
	foreach ( $product->get_attributes() as $a ) {
		if ( in_array( strtolower( $a->get_name() ), $names, true ) ) {
			return [ $a->get_name(), $a->is_taxonomy() ? wc_get_product_terms( $product->get_id(), $a->get_name(), [ 'fields' => 'names' ] ) : $a->get_options() ];
		}
	}
	return [ '', [] ];
}

/** All published products in menu order, shaped for the cards and window.WJ. */
function wj_products() {
	static $out = null;
	if ( $out !== null ) return $out;
	$out = [];
	foreach ( wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ] ) as $i => $p ) {
		$cats                       = wp_get_post_terms( $p->get_id(), 'product_cat', [ 'fields' => 'slugs' ] );
		[ $size_label, $sizes ]     = wj_attr_options( $p, [ 'size', 'size run', 'pa_size' ] );
		[ , $colours ]              = wj_attr_options( $p, [ 'colour', 'color', 'pa_colour', 'pa_color' ] );
		$whole                      = (int) $p->get_meta( '_wj_wholesale' );
		$price                      = (int) $p->get_regular_price();
		$out[]                      = [
			'id'        => $p->get_slug(),
			'name'      => $p->get_name(),
			'price'     => $price,
			'whole'     => $whole && $whole < $price ? $whole : 0,
			'cat'       => $cats[0] ?? '',
			'desc'      => wp_strip_all_tags( $p->get_short_description() ),
			'img'       => (string) get_the_post_thumbnail_url( $p->get_id(), 'full' ),
			'sizeLabel' => $size_label ?: 'Size',
			'sizes'     => array_values( array_map( 'strval', $sizes ) ),
			'colours'   => array_values( array_map( 'strval', $colours ) ),
			'badge'     => (string) $p->get_meta( '_wj_badge' ),
			'new'       => $p->get_meta( '_wj_new' ) === 'yes',
			'sample'    => $p->get_meta( '_wj_sample' ) === 'yes',
			'order'     => $i,
		];
	}
	return $out;
}

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	wp_enqueue_style( 'wj-fonts', WJ_FONTS, [], null );
	wp_enqueue_style( 'wj', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'wj', wj_asset( 'wj.js' ), [], filemtime( $dir . '/assets/wj.js' ), true );
	$products = [];
	foreach ( wj_products() as $p ) {
		$products[ $p['id'] ] = array_intersect_key( $p, array_flip( [ 'name', 'price', 'whole', 'cat', 'desc', 'img', 'sizeLabel', 'sizes', 'colours', 'badge' ] ) );
	}
	$cats = [];
	foreach ( wj_categories() as $slug => $c ) $cats[ $slug ] = $c['name'];
	wp_add_inline_script( 'wj', 'window.WJ=' . wp_json_encode( [
		'wa'       => WJ_WA,
		'phone'    => WJ_PHONE,
		'moq'      => WJ_MOQ,
		'freeOver' => WJ_FREE_OVER,
		'delivery' => WJ_DELIVERY,
		'payments' => WJ_PAYMENTS,
		'cats'     => $cats,
		'products' => $products,
	] ) . ';', 'before' );
	foreach ( [ 'woocommerce-general', 'woocommerce-layout', 'woocommerce-smallscreen', 'wc-blocks-style' ] as $h ) wp_dequeue_style( $h );
}, 20 );
add_action( 'wp_enqueue_scripts', function () {
	foreach ( [ 'woocommerce', 'wc-add-to-cart', 'wc-cart-fragments', 'jquery-blockui', 'wc-jquery-blockui', 'js-cookie', 'wc-js-cookie', 'sourcebuster-js', 'wc-order-attribution' ] as $h ) {
		wp_dequeue_script( $h );
	}
}, 100 );
add_filter( 'wc_order_attribution_allow_tracking', '__return_false' );
add_filter( 'pre_option_woocommerce_feature_order_attribution_enabled', fn() => 'no' );
add_action( 'enqueue_block_editor_assets', fn() => wp_enqueue_style( 'wj-fonts', WJ_FONTS, [], null ) );
add_action( 'after_setup_theme', fn() => add_editor_style( 'style.css' ) );

const WJ_TITLE = 'Wajose Main Shop | Executive Loafers, Sneakers & Menswear · Wholesale & Retail, Nairobi';
const WJ_DESC  = 'Premium men’s footwear and fashion in Nairobi: leather loafers, chain-detail slip-ons, sneakers and menswear at retail and wholesale prices. Open 24 hours. Order on WhatsApp 0787 396 079.';
add_filter( 'pre_get_document_title', fn( $t ) => is_front_page() ? WJ_TITLE : $t );
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('wj-js')</script>\n";
	echo '<link rel="icon" href="' . esc_url( wj_asset( 'icon-32.png' ) ) . '" sizes="32x32" type="image/png">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( wj_asset( 'icon-512.png' ) ) . '">' . "\n";
	echo '<meta name="theme-color" content="#121212">' . "\n";
	if ( ! is_front_page() ) return;
	printf(
		'<meta name="description" content="%1$s"><meta property="og:type" content="website"><meta property="og:locale" content="en_KE"><meta property="og:title" content="%2$s"><meta property="og:description" content="%3$s"><meta property="og:image" content="%4$s">' . "\n",
		esc_attr( WJ_DESC ),
		esc_attr( 'Wajose Main Shop: Step Into Elegance' ),
		esc_attr( 'Executive footwear, sneakers and menswear. Wholesale & retail, 24/7 Nairobi delivery.' ),
		esc_url( wj_asset( 'img/hero.jpg' ) )
	);
}, 1 );

add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );
add_filter( 'pre_option_woocommerce_coming_soon', fn() => 'no' );
add_filter( 'woocommerce_coming_soon_exclude', '__return_true' );

// Orders are placed from the theme's cart (WhatsApp or the checkout form), so WooCommerce's own cart stays off.
add_filter( 'woocommerce_is_purchasable', '__return_false' );
// The shop page, a category or a product page open the one-page shop instead.
add_action( 'template_redirect', function () {
	if ( is_shop() || is_product_category() ) {
		$slug = is_product_category() ? get_queried_object()->slug : '';
		wp_safe_redirect( home_url( '/' . ( $slug ? '?cat=' . $slug : '' ) . '#shop' ), 301 );
		exit;
	}
	if ( is_product() ) {
		wp_safe_redirect( home_url( '/?p=' . get_post_field( 'post_name', get_queried_object_id() ) . '#shop' ), 301 );
		exit;
	}
} );

/* Shop ------------------------------------------------------------------------------------------------------------ */

function wj_card( $p, $cats ) {
	$badge = $p['badge'] ? '<span class="wj-badge' . ( $p['cat'] === 'wholesale' ? ' wj-badge--gold' : '' ) . '">' . esc_html( $p['badge'] ) . '</span>' : '';
	$whole = $p['whole']
		? '<p class="wj-card__whole">' . wj_icon( 'tag', 13 ) . '<span>Wholesale <b>' . wj_ksh( $p['whole'] ) . '</b> from&nbsp;' . WJ_MOQ . '&nbsp;pcs</span></p>'
		: ( $p['cat'] === 'wholesale' ? '<p class="wj-card__whole">' . wj_icon( 'box', 13 ) . '<span>Bulk price, delivered countrywide</span></p>' : '' );
	$chips = '';
	if ( $p['cat'] !== 'wholesale' ) {
		foreach ( $p['sizes'] as $s ) {
			$chips .= sprintf( '<button type="button" data-wj-quick="%1$s" data-size="%2$s" aria-label="Size %2$s">%2$s</button>', esc_attr( $p['id'] ), esc_attr( $s ) );
		}
		$chips = '<div class="wj-card__sizes" aria-label="Available sizes">' . $chips . '</div>';
	}
	return sprintf(
		'<li class="wj-card" id="p-%1$s" data-cat="%2$s" data-sizes="%3$s" data-price="%4$d" data-order="%5$d" data-new="%6$s">'
		. '<div class="wj-card__media"><img src="%7$s" alt="%8$s" loading="lazy" width="800" height="1000">%9$s'
		. '<button type="button" class="wj-card__quick" data-wj-quick="%1$s">%10$s Quick buy</button></div>'
		. '<div class="wj-card__body"><p class="wj-card__cat">%11$s</p><h3><button type="button" data-wj-quick="%1$s">%8$s</button></h3>'
		. '<p class="wj-card__price">%12$s</p>%13$s%14$s</div></li>',
		esc_attr( $p['id'] ),
		esc_attr( $p['cat'] ),
		esc_attr( implode( ' ', $p['sizes'] ) ),
		$p['price'],
		$p['order'],
		$p['new'] ? '1' : '0',
		esc_url( $p['img'] ),
		esc_html( $p['name'] ),
		$badge,
		wj_icon( 'bag', 15 ),
		esc_html( $cats[ $p['cat'] ]['name'] ?? '' ),
		wj_ksh( $p['price'] ),
		$whole,
		$chips
	);
}

add_shortcode( 'wj_shop', function () {
	$cats  = wj_categories();
	$all   = wj_products();
	$tabs  = '<button type="button" class="is-on" data-wj-cat="all" aria-pressed="true">Shop all</button>';
	$notes = '<p data-wj-cat-note="all">Executive footwear, sneakers and menswear at retail prices, with wholesale pricing from ' . WJ_MOQ . ' pieces of a style.</p>';
	foreach ( $cats as $slug => $c ) {
		$short  = [ 'executive' => 'Executive & loafers', 'sneakers' => 'Sneakers', 'apparel' => 'Menswear', 'wholesale' => 'Bulk packs' ];
		$tabs  .= sprintf( '<button type="button" data-wj-cat="%1$s" aria-pressed="false">%2$s</button>', esc_attr( $slug ), esc_html( $short[ $slug ] ?? $c['name'] ) );
		$notes .= sprintf( '<p data-wj-cat-note="%1$s" hidden>%2$s</p>', esc_attr( $slug ), esc_html( $c['blurb'] ) );
	}
	$tabs  .= '<button type="button" data-wj-cat="new" aria-pressed="false">New arrivals</button>';
	$notes .= '<p data-wj-cat-note="new" hidden>Just landed at the hub: this week’s new styles and limited drops.</p>';

	// Size filter: every shoe and clothing size on sale, shoes first.
	$shoe = $cloth = [];
	foreach ( $all as $p ) {
		if ( $p['cat'] === 'wholesale' ) continue;
		foreach ( $p['sizes'] as $s ) {
			if ( is_numeric( $s ) && (int) $s >= 35 ) $shoe[ $s ] = true;
			else $cloth[ $s ] = true;
		}
	}
	ksort( $shoe, SORT_NUMERIC );
	$order = [ 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL' ];
	uksort( $cloth, fn( $a, $b ) => is_numeric( $a ) && is_numeric( $b ) ? $a <=> $b : ( is_numeric( $a ) ? 1 : ( is_numeric( $b ) ? -1 : array_search( $a, $order, true ) <=> array_search( $b, $order, true ) ) ) );
	$opt = fn( $list ) => implode( '', array_map( fn( $s ) => '<option value="' . esc_attr( $s ) . '">' . esc_html( $s ) . '</option>', array_keys( $list ) ) );

	$cards = '';
	foreach ( $all as $p ) $cards .= wj_card( $p, $cats );
	$sample = WJ_PREVIEW ? '<p class="wj-note">Preview: product photos are stock images and all prices are samples until Wajose confirms its price list.</p>' : '';
	return '<div class="wj-shop" data-wj-shop>'
		. '<div class="wj-tabs" role="group" aria-label="Filter by category">' . $tabs . '</div>'
		. '<div class="wj-toolbar"><div class="wj-shop-notes">' . $notes . '</div><div class="wj-toolbar__controls">'
		. '<label class="wj-select"><span>' . wj_icon( 'ruler', 14 ) . ' Size</span><select data-wj-size><option value="">Any size</option><optgroup label="Shoes (EU)">' . $opt( $shoe ) . '</optgroup><optgroup label="Clothing">' . $opt( $cloth ) . '</optgroup></select></label>'
		. '<label class="wj-select"><span>' . wj_icon( 'filter', 14 ) . ' Sort</span><select data-wj-sort><option value="featured">Featured</option><option value="new">Newest first</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></label>'
		. '</div></div>'
		. '<p class="wj-count" data-wj-results aria-live="polite">' . count( $all ) . ' styles</p>'
		. '<ul class="wj-cards is-capped">' . $cards . '</ul>'
		. '<p class="wj-empty" data-wj-none hidden>No styles in that size here yet. <button type="button" class="wj-linkbtn" data-wj-reset>Clear filters</button> or <a href="' . esc_url( wj_wa( 'Hi Wajose! Do you have this style in my size? ' ) ) . '" target="_blank" rel="noopener">ask us on WhatsApp</a>.</p>'
		. '<button type="button" class="wj-btn wj-btn--line wj-more" data-wj-more>Show all ' . count( $all ) . ' styles</button>' . $sample . '</div>';
} );

/* Wholesale ------------------------------------------------------------------------------------------------------- */

add_shortcode( 'wj_wholesale', function () {
	$tiers = [
		[ 'Retail', '1–' . ( WJ_MOQ - 1 ) . ' pieces', 'Shelf price, any size or colour, delivered 24/7.' ],
		[ 'Wholesale', WJ_MOQ . '+ pieces of a style', 'Wholesale price per piece. Mix sizes and colours within a style.' ],
		[ 'Bulk packs', '12–24 pieces', 'Curated packs with a full size run, our lowest price per pair.' ],
		[ 'Reseller account', 'Repeat orders', 'Priority restocks, new-arrival previews and countrywide dispatch.' ],
	];
	$t = '';
	foreach ( $tiers as $i => [ $name, $qty, $desc ] ) {
		$t .= sprintf( '<li%4$s><span class="wj-tier__n">0%5$d</span><b>%1$s</b><em>%2$s</em><p>%3$s</p></li>', esc_html( $name ), esc_html( $qty ), esc_html( $desc ), $i === 1 ? ' class="is-key"' : '', $i + 1 );
	}
	$interest = '';
	foreach ( [ 'Executive loafers', 'Sneakers', 'Menswear', 'Bulk packs' ] as $x ) {
		$interest .= '<label class="wj-check"><input type="checkbox" name="wj-int" value="' . esc_attr( $x ) . '"><span>' . esc_html( $x ) . '</span></label>';
	}
	ob_start();
	?>
<div class="wj-whole">
	<div class="wj-whole__copy">
		<p class="wj-eyebrow">Wholesale &amp; bulk</p>
		<h2>Stock your boutique <em>from the main shop</em></h2>
		<p class="wj-lead">Retail and wholesale under one roof. Buy <?php echo (int) WJ_MOQ; ?> or more of a style and the wholesale price applies automatically in your cart, or take a curated bulk pack with a ready-made size run.</p>
		<ol class="wj-tiers"><?php echo $t; ?></ol>
		<p class="wj-small"><?php echo wj_icon( 'truck', 16 ); ?> Packed and dispatched countrywide by courier or your preferred sacco. <?php echo WJ_PREVIEW ? 'Tiers and minimums are samples.' : ''; ?></p>
	</div>
	<form class="wj-whole__form" data-wj-wholesale novalidate>
		<h3>Wholesale inquiry</h3>
		<p class="wj-muted">Tell us what you stock. We reply on WhatsApp with today’s wholesale price list and photos.</p>
		<div class="wj-grid2">
			<label class="wj-field"><span>Business name</span><input name="biz" autocomplete="organization" placeholder="e.g. Kamau Kicks" required></label>
			<label class="wj-field"><span>Your name</span><input name="name" autocomplete="name" placeholder="Full name" required></label>
			<label class="wj-field"><span>Phone / WhatsApp</span><input name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="07XX XXX XXX" required></label>
			<label class="wj-field"><span>Town</span><input name="town" autocomplete="address-level2" placeholder="e.g. Nakuru" required></label>
		</div>
		<fieldset class="wj-field"><legend>Interested in</legend><div class="wj-checks"><?php echo $interest; ?></div></fieldset>
		<label class="wj-field"><span>Order size</span><select name="qty"><option>6–11 pieces</option><option selected>12–24 pieces</option><option>25–50 pieces</option><option>50+ pieces</option></select></label>
		<label class="wj-field"><span>Notes (optional)</span><textarea name="notes" rows="2" placeholder="Styles, sizes, budget or delivery date"></textarea></label>
		<p class="wj-form-error" data-wj-error hidden></p>
		<button type="submit" class="wj-btn wj-btn--gold wj-btn--block"><?php echo wj_icon( 'wa', 18 ); ?> Send inquiry on WhatsApp</button>
	</form>
</div>
	<?php
	return ob_get_clean();
} );

/* Content sections ------------------------------------------------------------------------------------------------ */

add_shortcode( 'wj_reviews', function () {
	$out = '';
	foreach ( WJ_REVIEWS as [ $quote, $name, $role ] ) {
		$out .= sprintf( '<li class="wj-review"><p class="wj-stars" aria-label="5 out of 5 stars">%4$s</p><blockquote>&ldquo;%1$s&rdquo;</blockquote><p class="wj-review__name">%2$s</p><p class="wj-review__role">%3$s</p></li>', esc_html( $quote ), esc_html( $name ), esc_html( $role ), str_repeat( wj_icon( 'star', 15 ), 5 ) );
	}
	$note = WJ_PREVIEW ? '<p class="wj-note wj-note--dark">Sample reviews for the preview. Real customer reviews go here with their permission.</p>' : '';
	return '<div class="wj-carousel" data-wj-carousel><ul class="wj-reviews" data-wj-track>' . $out . '</ul>'
		. '<div class="wj-carousel__nav"><button type="button" data-wj-prev aria-label="Previous review">←</button><div class="wj-dots" data-wj-dots></div><button type="button" data-wj-next aria-label="Next review">→</button></div></div>' . $note;
} );

add_shortcode( 'wj_lookbook', function () {
	$out = '';
	foreach ( WJ_LOOKBOOK as [ $img, $cap, $wide ] ) {
		$out .= sprintf( '<li%3$s><img src="%1$s" alt="%2$s" loading="lazy"><span>%2$s</span></li>', esc_url( wj_asset( 'img/' . $img ) ), esc_attr( $cap ), $wide ? ' class="is-wide"' : '' );
	}
	return '<ul class="wj-look">' . $out . '</ul>';
} );

function wj_faq() {
	$fees = [];
	foreach ( WJ_DELIVERY as $d ) if ( $d['fee'] ) $fees[] = $d['label'] . ' ' . wj_ksh( $d['fee'] );
	return [
		[ 'Where is your hub, and can I visit?', 'Our main shop and dispatch hub is in Nairobi and we run 24 hours a day. WhatsApp ' . WJ_PHONE . ' and we’ll send a live location pin, or have a rider bring your order to you.' ],
		[ 'How do I find my size?', 'Our shoes run in standard EU sizes. Measure your foot from heel to longest toe and use the size guide above. Between sizes, or wide feet? Go one size up on loafers, and tell us in your order note so we can send photos of both sizes first.' ],
		[ 'Can I exchange or return?', 'Yes. Exchange unworn items in their original box within 7 days for another size or style. If an item arrives faulty we replace it free. We don’t refund cash on worn items or bulk packs.' ],
		[ 'What are the wholesale minimums?', 'The wholesale price applies from ' . WJ_MOQ . ' pieces of one style, and you can mix sizes and colours. Bulk packs start at 12 pairs and carry our lowest price per pair. Larger or repeat orders get a reseller price list: send a wholesale inquiry.' ],
		[ 'How much is delivery?', implode( ' · ', $fees ) . '. Collection from our hub is free, and Nairobi rider delivery is free on orders over ' . wj_ksh( WJ_FREE_OVER ) . '.' ],
		[ 'How do I pay?', 'M-Pesa (Till or Paybill details come with your order confirmation), bank transfer, or cash on delivery for Nairobi rider orders. Card payments on request. We never ask for payment before confirming your sizes are in stock.' ],
	];
}
add_shortcode( 'wj_faq', function () {
	$out = '';
	foreach ( wj_faq() as $i => [ $q, $a ] ) {
		$out .= sprintf( '<details%1$s><summary>%2$s<span aria-hidden="true"></span></summary><p>%3$s</p></details>', $i ? '' : ' open', esc_html( $q ), esc_html( $a ) );
	}
	$note = WJ_PREVIEW ? '<p class="wj-note">Preview: delivery fees, the exchange window and wholesale minimums are samples until Wajose confirms them.</p>' : '';
	return '<div class="wj-faq">' . $out . '</div>' . $note;
} );

add_shortcode( 'wj_sizes', function () {
	$rows = [ [ 39, 6, 7, '24.6' ], [ 40, 6.5, 7.5, '25.3' ], [ 41, 7.5, 8.5, '26.0' ], [ 42, 8, 9, '26.7' ], [ 43, 9, 10, '27.3' ], [ 44, 9.5, 10.5, '28.0' ], [ 45, 10.5, 11.5, '28.6' ], [ 46, 11, 12, '29.3' ] ];
	$tr   = '';
	foreach ( $rows as [ $eu, $uk, $us, $cm ] ) $tr .= "<tr><th scope=\"row\">$eu</th><td>$uk</td><td>$us</td><td>$cm</td></tr>";
	return '<div class="wj-sizes"><h3>' . wj_icon( 'ruler', 18 ) . ' Shoe size guide</h3><table><thead><tr><th scope="col">EU</th><th scope="col">UK</th><th scope="col">US</th><th scope="col">Foot (cm)</th></tr></thead><tbody>' . $tr . '</tbody></table>'
		. '<p class="wj-small">Clothing: S (chest 92 cm) · M (98) · L (104) · XL (110) · XXL (116). Trousers by waist in inches, 30–38.</p></div>';
} );

add_shortcode( 'wj_footer', function () {
	$map = 'https://maps.google.com/maps?q=' . rawurlencode( WJ_MAP_Q ) . '&z=14&output=embed';
	$pay = '';
	foreach ( [ [ 'mpesa', 'M-Pesa Till / Paybill' ], [ 'card', 'Visa / Mastercard' ], [ 'cash', 'Cash on delivery' ] ] as [ $i, $l ] ) $pay .= '<li>' . wj_icon( $i, 16 ) . esc_html( $l ) . '</li>';
	$hi = 'Hi Wajose! ';
	ob_start();
	?>
<section class="wj-visit" id="location">
	<div class="wj-visit__map"><iframe title="Map: Wajose Main Shop, Nairobi" src="<?php echo esc_url( $map ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
	<div class="wj-visit__card">
		<p class="wj-eyebrow">Location hub</p>
		<h2>Nairobi main shop <em>&amp; dispatch</em></h2>
		<p class="wj-visit__line"><?php echo wj_icon( 'pin', 18 ); ?> <?php echo esc_html( WJ_CITY ); ?>, Kenya · live pin on WhatsApp</p>
		<p class="wj-visit__line"><?php echo wj_icon( 'clock', 18 ); ?> Open 24 hours, every day <b class="wj-open">Open now</b></p>
		<p class="wj-visit__line"><?php echo wj_icon( 'truck', 18 ); ?> Riders across Nairobi day and night · couriers countrywide</p>
		<div class="wj-visit__ctas">
			<a class="wj-btn wj-btn--gold" href="<?php echo esc_url( wj_wa( $hi . 'Please send me your location pin.' ) ); ?>" target="_blank" rel="noopener"><?php echo wj_icon( 'wa', 17 ); ?> Get directions on WhatsApp</a>
			<a class="wj-btn wj-btn--ghost" href="tel:<?php echo WJ_TEL; ?>"><?php echo wj_icon( 'phone', 16 ); ?> Call <?php echo esc_html( WJ_PHONE ); ?></a>
		</div>
	</div>
</section>
<div class="wj-foot">
	<div class="wj-foot__brand">
		<?php echo wj_logo_full(); ?>
		<p>Uncompromising style · Premium footwear &amp; fashion · Wholesale &amp; retail excellence. Executive footwear, menswear and bulk fashion from Nairobi to every town in Kenya.</p>
		<div class="wj-social">
			<a href="<?php echo esc_url( WJ_IG ); ?>" target="_blank" rel="noopener" aria-label="Wajose on Instagram"><?php echo wj_icon( 'ig', 18 ); ?></a>
			<a href="<?php echo esc_url( WJ_TT ); ?>" target="_blank" rel="noopener" aria-label="Wajose on TikTok"><?php echo wj_icon( 'tiktok', 18 ); ?></a>
			<a href="<?php echo esc_url( wj_wa( $hi ) ); ?>" target="_blank" rel="noopener" aria-label="WhatsApp Wajose"><?php echo wj_icon( 'wa', 18 ); ?></a>
		</div>
	</div>
	<nav aria-label="Shop">
		<h3>Shop</h3>
		<a href="/#shop">Shop all</a>
		<a href="/?cat=executive#shop">Executive footwear</a>
		<a href="/?cat=sneakers#shop">Loafers &amp; sneakers</a>
		<a href="/?cat=apparel#shop">Menswear</a>
		<a href="/?cat=new#shop">New arrivals</a>
		<a href="/#wholesale">Wholesale &amp; bulk</a>
	</nav>
	<nav aria-label="Help">
		<h3>Help</h3>
		<a href="/#faq">Size guide</a>
		<a href="/#faq">Exchanges &amp; returns</a>
		<a href="/#faq">Delivery &amp; payment</a>
		<a href="/#about">About us</a>
		<a href="/#location">Location</a>
	</nav>
	<div>
		<h3>Contact</h3>
		<p><a href="tel:<?php echo WJ_TEL; ?>"><?php echo wj_icon( 'phone', 15 ); ?> <?php echo esc_html( WJ_PHONE ); ?></a></p>
		<p><a href="<?php echo esc_url( wj_wa( $hi ) ); ?>" target="_blank" rel="noopener"><?php echo wj_icon( 'wa', 15 ); ?> WhatsApp orders</a></p>
		<p><a href="<?php echo esc_url( WJ_IG ); ?>" target="_blank" rel="noopener"><?php echo wj_icon( 'ig', 15 ); ?> <?php echo esc_html( WJ_HANDLE ); ?></a></p>
		<h3 class="wj-foot__pay-h">We accept</h3>
		<ul class="wj-pay"><?php echo $pay; ?></ul>
	</div>
</div>
<p class="wj-copy">© <?php echo esc_html( gmdate( 'Y' ) ); ?> Wajose Main Shop · Nairobi, Kenya<?php echo WJ_PREVIEW ? '<span>Preview build: photos are stock images; prices, delivery fees, policies, reviews and the map pin are samples.</span>' : ''; ?></p>
<p class="wj-credit">Developed by <a href="mailto:salvatorewanjohi@gmail.com">Wahome</a></p>
	<?php
	return ob_get_clean();
} );

add_shortcode( 'wj_icon', fn( $a ) => wj_icon( $a['name'] ?? 'crown', (int) ( $a['size'] ?? 22 ) ) );
add_shortcode( 'wj_count', fn() => (string) count( wj_products() ) );

/* Quick-buy dialog, cart drawer, toasts and the floating WhatsApp button: one copy per page, driven by wj.js ------- */
add_action( 'wp_footer', function () {
	$deliv = $pay = '';
	foreach ( WJ_DELIVERY as $k => $d ) {
		$deliv .= sprintf( '<label class="wj-opt"><input type="radio" name="wj-deliv" value="%1$s"%2$s><span><b>%3$s</b><small>%4$s</small></span><em data-wj-fee="%1$s">%5$s</em></label>', esc_attr( $k ), $k === 'rider' ? ' checked' : '', esc_html( $d['label'] ), esc_html( $d['detail'] ), $d['fee'] ? wj_ksh( $d['fee'] ) : 'Free' );
	}
	foreach ( WJ_PAYMENTS as $k => [ $label, $detail ] ) {
		$pay .= sprintf( '<label class="wj-opt wj-opt--sm"><input type="radio" name="wj-pay" value="%1$s"%2$s><span><b>%3$s</b><small>%4$s</small></span></label>', esc_attr( $k ), $k === 'mpesa' ? ' checked' : '', esc_html( $label ), esc_html( $detail ) );
	}
	?>
<div class="wj-modal" data-wj-modal hidden>
	<button type="button" class="wj-shade" data-wj-close-modal aria-label="Close"></button>
	<div class="wj-modal__panel" role="dialog" aria-modal="true" aria-labelledby="wj-q-name">
		<button type="button" class="wj-x" data-wj-close-modal aria-label="Close">×</button>
		<div class="wj-modal__media"><img data-wj-q-img src="" alt=""><span class="wj-badge" data-wj-q-badge hidden></span></div>
		<div class="wj-modal__body">
			<p class="wj-card__cat" data-wj-q-cat></p>
			<h2 id="wj-q-name" data-wj-q-name></h2>
			<p class="wj-muted" data-wj-q-desc></p>
			<div class="wj-q-prices"><p><span>Retail</span><b data-wj-q-price></b></p><p data-wj-q-wholewrap><span>Wholesale (<?php echo (int) WJ_MOQ; ?>+ pcs)</span><b data-wj-q-whole></b></p></div>
			<fieldset class="wj-q-group"><legend><span data-wj-q-sizelabel>Size</span> <small data-wj-q-sizehint></small></legend><div class="wj-chips" data-wj-q-sizes></div></fieldset>
			<fieldset class="wj-q-group"><legend>Colour <small data-wj-q-colour></small></legend><div class="wj-chips" data-wj-q-colours></div></fieldset>
			<div class="wj-q-row">
				<div class="wj-qty" aria-label="Quantity"><button type="button" data-wj-q-step="-1" aria-label="Decrease quantity">−</button><input data-wj-q-qty type="number" min="1" max="500" value="1" inputmode="numeric" aria-label="Quantity"><button type="button" data-wj-q-step="1" aria-label="Increase quantity">+</button></div>
				<p class="wj-q-sub"><span>Subtotal</span><b data-wj-q-sub></b><small data-wj-q-tier></small></p>
			</div>
			<p class="wj-form-error" data-wj-q-error hidden></p>
			<div class="wj-q-actions">
				<button type="button" class="wj-btn wj-btn--dark wj-btn--block" data-wj-q-add><?php echo wj_icon( 'bag', 17 ); ?> Add to cart</button>
				<a class="wj-btn wj-btn--wa wj-btn--block" data-wj-q-wa href="#" target="_blank" rel="noopener"><?php echo wj_icon( 'wa', 17 ); ?> Buy now on WhatsApp</a>
			</div>
			<p class="wj-small"><?php echo wj_icon( 'swap', 14 ); ?> Free size exchange within 7 days · <a href="#faq" data-wj-close-modal>Size guide</a></p>
		</div>
	</div>
</div>

<div class="wj-drawer" data-wj-drawer hidden>
	<button type="button" class="wj-shade" data-wj-close aria-label="Close cart"></button>
	<aside class="wj-drawer__panel" role="dialog" aria-modal="true" aria-label="Shopping cart">
		<header class="wj-drawer__head"><h2>Your cart <small data-wj-cart-count></small></h2><button type="button" class="wj-x" data-wj-close aria-label="Close cart">×</button></header>
		<div class="wj-drawer__empty" data-wj-empty>
			<span class="wj-round"><?php echo wj_icon( 'bag', 28 ); ?></span>
			<p class="wj-drawer__empty-title">Your cart is empty</p>
			<p class="wj-muted">Executive loafers, sneakers and menswear, delivered 24/7.</p>
			<a class="wj-btn wj-btn--gold" href="#shop" data-wj-close>Explore the collection</a>
		</div>
		<div class="wj-drawer__full" data-wj-full hidden>
			<div class="wj-drawer__scroll">
				<ul class="wj-lines" data-wj-lines></ul>
				<p class="wj-tierhint" data-wj-tierhint hidden></p>
				<section class="wj-co">
					<p class="wj-eyebrow wj-eyebrow--ink">Delivery</p>
					<div class="wj-opts"><?php echo $deliv; ?></div>
					<p class="wj-eyebrow wj-eyebrow--ink">How would you like to check out?</p>
					<div class="wj-mode" role="tablist" aria-label="Checkout mode">
						<button type="button" role="tab" class="is-on" aria-selected="true" data-wj-mode="wa"><?php echo wj_icon( 'wa', 16 ); ?> WhatsApp checkout</button>
						<button type="button" role="tab" aria-selected="false" data-wj-mode="form"><?php echo wj_icon( 'card', 16 ); ?> Checkout form</button>
					</div>
					<p class="wj-small" data-wj-mode-note="wa">Send your itemised cart to <?php echo esc_html( WJ_PHONE ); ?>. We confirm stock, delivery and payment in the chat.</p>
					<div class="wj-coform" data-wj-mode-note="form" hidden>
						<p class="wj-small">Fill in your details once. We confirm stock and send payment details with your order number.</p>
						<label class="wj-field"><span>Full name</span><input data-wj-f="name" autocomplete="name" placeholder="e.g. Brian Otieno"></label>
						<label class="wj-field"><span>Phone number</span><input data-wj-f="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="07XX XXX XXX"></label>
						<label class="wj-field" data-wj-addr><span data-wj-addr-label>Delivery address in Nairobi</span><input data-wj-f="address" autocomplete="street-address" placeholder="Estate, street, building, house no."></label>
						<label class="wj-field"><span>Delivery instructions (optional)</span><textarea data-wj-f="notes" rows="2" placeholder="Gate code, best time, landmark…"></textarea></label>
						<fieldset class="wj-field"><legend>Payment</legend><div class="wj-opts"><?php echo $pay; ?></div></fieldset>
					</div>
				</section>
			</div>
			<div class="wj-drawer__foot">
				<dl class="wj-sum">
					<div><dt>Subtotal</dt><dd data-wj-subtotal></dd></div>
					<div class="wj-sum__save" data-wj-savewrap hidden><dt>Wholesale savings</dt><dd data-wj-save></dd></div>
					<div><dt data-wj-deliv-label>Delivery</dt><dd data-wj-deliv-fee></dd></div>
					<div class="wj-sum__total"><dt>Total</dt><dd data-wj-grand></dd></div>
				</dl>
				<p class="wj-form-error" data-wj-co-error hidden></p>
				<a class="wj-btn wj-btn--wa wj-btn--block" data-wj-checkout href="#" target="_blank" rel="noopener"><?php echo wj_icon( 'wa', 18 ); ?> <span data-wj-checkout-label>Send order on WhatsApp</span></a>
				<p class="wj-drawer__small"><span>M-Pesa · bank · cash on delivery</span><button type="button" data-wj-clear>Clear cart</button></p>
			</div>
		</div>
	</aside>
</div>
<div class="wj-toasts" data-wj-toasts aria-live="polite"></div>
<a class="wj-float-wa" href="<?php echo esc_url( wj_wa( 'Hi Wajose! ' ) ); ?>" target="_blank" rel="noopener" aria-label="Chat with Wajose on WhatsApp"><?php echo wj_icon( 'wa', 28 ); ?></a>
	<?php
	$store = [
		'@type'        => 'ShoeStore',
		'name'         => WJ_NAME,
		'slogan'       => 'Uncompromising Style • Premium Footwear & Fashion • Wholesale & Retail Excellence',
		'telephone'    => WJ_TEL,
		'address'      => [ '@type' => 'PostalAddress', 'addressLocality' => 'Nairobi', 'addressCountry' => 'KE' ],
		'openingHours' => 'Mo-Su 00:00-23:59',
		'priceRange'   => 'KSh 1,500–6,500',
		'sameAs'       => [ WJ_IG, WJ_TT ],
		'url'          => home_url( '/' ),
	];
	echo '<script type="application/ld+json">' . wp_json_encode( [ '@context' => 'https://schema.org', '@graph' => [ $store ] ] ) . '</script>';
} );

/* Product editor: Wajose fields under Product data → General ------------------------------------------------------- */
add_action( 'woocommerce_product_options_general_product_data', function () {
	echo '<div class="options_group"><p class="form-field"><strong>Wajose shop card</strong> &nbsp;Sizes and colours are under Attributes (names "Size" and "Colour").</p>';
	woocommerce_wp_text_input( [ 'id' => '_wj_wholesale', 'label' => 'Wholesale price (KSh)', 'type' => 'number', 'description' => 'Per piece, from ' . WJ_MOQ . ' pieces of this style. Leave empty for none.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_wj_badge', 'label' => 'Badge', 'description' => 'Short tag on the photo, e.g. Bestseller or Limited drop.', 'desc_tip' => true ] );
	woocommerce_wp_checkbox( [ 'id' => '_wj_new', 'label' => 'New arrival', 'description' => 'Shows under New arrivals.' ] );
	woocommerce_wp_checkbox( [ 'id' => '_wj_sample', 'label' => 'Sample price', 'description' => 'Price not yet confirmed by the shop.' ] );
	echo '</div>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_wj_wholesale', '_wj_badge' ] as $key ) {
		if ( isset( $_POST[ $key ] ) ) $product->update_meta_data( $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
	}
	$product->update_meta_data( '_wj_new', isset( $_POST['_wj_new'] ) ? 'yes' : 'no' );
	$product->update_meta_data( '_wj_sample', isset( $_POST['_wj_sample'] ) ? 'yes' : 'no' );
} );

// Pitch build: out of search results until Wajose signs off on prices, photos and copy.
if ( WJ_PREVIEW ) add_filter( 'wp_robots', fn( $r ) => array_merge( $r, [ 'noindex' => true, 'nofollow' => true ] ) );

// WooCommerce hooks a mini-cart and an account link into the header navigation; the theme has its own cart.
add_filter( 'hooked_block_types', fn( $types ) => array_values( array_diff( $types, [ 'woocommerce/mini-cart', 'woocommerce/customer-account' ] ) ), 20 );

// The shortcode block runs wpautop, which wraps markup in <p>. All shortcode blocks here return finished markup.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	if ( ( $block['blockName'] ?? '' ) === 'core/shortcode' ) {
		return do_shortcode( trim( $block['innerHTML'] ) );
	}
	return $pre;
}, 10, 2 );
